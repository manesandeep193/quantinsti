import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { CreatePizza } from './component/createPizza';
import { checkoutPizza } from './component/pizzaCheckout';

const routes: Routes = [
  { path: '', redirectTo: '/pizza', pathMatch: 'full' },
  {path: 'pizza', component: CreatePizza},
  {path: 'checkout', component: checkoutPizza}
];

@NgModule({
  declarations: [
    AppComponent,
    CreatePizza,
    checkoutPizza
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
