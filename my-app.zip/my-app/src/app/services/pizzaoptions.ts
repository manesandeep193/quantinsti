import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class PizzaOptionsService {
    private userPizza;
  constructor() { }
  getPizzaOptions(){
    const pizzaOptions ={
        "base":[
            {
                label: 'Normal',
                price: 300,
                checked:false
            },
            {
                label: 'Thin',
                price:350,
                checked:false
            }   
        ],
        'toppings':[
            {
                label:'Anchovies',
                price: 50
            },
            {
                label:'Bacon',
                price:100 
            },
            {
                label:'Canadian Bacon',
                price:150 
            },
            {
                label:'Chicken',
                price:100 
            },
            {
                label:'Italian Sausage',
                price:175
            },
            {
                label:'Sausage',
                price:125 
            },
            {
                label:'Pepperoni',
                price:90
            }
        ]
    }
    return pizzaOptions;
  }
  setUserPizza(pizza){
      this.userPizza = pizza;
  }
  getUserPizza(){
    return this.userPizza;
  }
}