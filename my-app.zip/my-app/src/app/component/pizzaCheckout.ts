import { Component, OnInit } from '@angular/core';
import { PizzaOptionsService } from '../../app/services/pizzaoptions';

@Component({
  selector: 'create-pizza',
  templateUrl: './pizzaCheckout.html'
})
export class checkoutPizza implements OnInit{
    private userPizza;
    private pizzaString;
    private pizzaPrice;
    private startPreparingPizza:boolean;
    private discountApplied:boolean = false;
  constructor(private PizzaOptionsService: PizzaOptionsService) { }
  ngOnInit() {
       this.userPizza = this.PizzaOptionsService.getUserPizza();
       this.createPizza();
  }
  createPizza(){    
    this.pizzaString = `So you have selected ${this.userPizza['base'][0]['label']} crust &`;
    this.pizzaString += this.getToppings();
    this.pizzaString += this.getPizzaPrize();
    this.startPreparingPizza = true;    
  }
  getToppings(){
    let pizzaToppings = this.userPizza['toppings'];
    let toppingText= 'you have chosen following toppings ';    
    for (let i =0; i < pizzaToppings.length; i++){
      toppingText+=pizzaToppings[i].label +",";      
    }    
    return toppingText;
  }
  getPizzaPrize(){
    this.pizzaPrice = 0;
    for(let key in this.userPizza){
      this.addPrizes(this.userPizza[key]);
    }
    return `. & price of your pizza is Rs.${this.pizzaPrice}.`;    
  } 
  addPrizes(pizza){
    for (let i =0; i < pizza.length; i++){      
      this.pizzaPrice += pizza[i].price;
    }    
  }
  changePizzaPrice(){
    let discount:number = (this.pizzaPrice/100)*10;
    this.pizzaPrice = this.pizzaPrice - discount;
    this.discountApplied = true;
  }
}