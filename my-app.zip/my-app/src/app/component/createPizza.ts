import { Component, OnInit } from '@angular/core';
import { PizzaOptionsService } from '../../app/services/pizzaoptions';
import { Router } from '@angular/router';

@Component({
  selector: 'create-pizza',
  templateUrl: './createPiza.html'
})
export class CreatePizza implements OnInit{
  constructor(private PizzaOptionsService: PizzaOptionsService,
    private router: Router) { }
  private pizzaOptions;
  private baseOptions;
  private toppingsOptions;
  private userPizza = {
    'base':[],
    'toppings':[]
  }
  ngOnInit() {
    this.pizzaOptions = this.PizzaOptionsService.getPizzaOptions();
    this.baseOptions = this.pizzaOptions['base'];
    this.toppingsOptions = this.pizzaOptions['toppings'];    
  }
  makePizza(type, selection, selectedValue){
    selectedValue.checked = !selectedValue.checked;
    if (selection) {
      this.userPizza[type].push(selectedValue);
    } else {
      this.removeFromPizza(type, selectedValue)
    }
    console.log(this.userPizza);
  } 
  removeFromPizza(type, selectedValue){
    let pizzaOptionToRemove = this.userPizza[type];    
    this.userPizza[type] = pizzaOptionToRemove.filter(function(element){
      return selectedValue.label !== element.label;
    });    
  }  
  createPizza(){
    this.PizzaOptionsService.setUserPizza(this.userPizza);
    this.router.navigate(['/checkout']);    
  }
}